# Hola mundo
print("Hola mundo")
print(5+8)
print("5+8")