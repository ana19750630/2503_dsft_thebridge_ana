for i in range(1, 4):   
    for j in range(1, 4):
        print(f'Coordenada: {i}, {j}')
        # time.sleep(2)
        if i == 2 and j == 2:
            print("Casilla central")
            
            
            
