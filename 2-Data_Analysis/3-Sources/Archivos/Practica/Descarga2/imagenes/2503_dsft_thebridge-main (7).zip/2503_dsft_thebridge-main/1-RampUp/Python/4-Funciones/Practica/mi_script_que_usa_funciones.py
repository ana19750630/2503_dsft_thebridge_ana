import funciones

print(funciones.circulo(20))
for i in range(20):
    print(funciones.fibonacci(i))